// Open the image popup
function openImage() {
    document.getElementById("popupImage").style.display = "flex";
  }
  
  // Close the image popup
  function closeImage() {
    document.getElementById("popupImage").style.display = "none";
  }
  